/*	Bat-Sinal (Batman)
Peça ao usuário quantas noites Gotham precisa de ajuda (N) e imprima "Bat-sinal ativado!" N vezes*/


programa {
  funcao inicio() {
    inteiro n 
    escreva ("Quantas noites Gotham precisa de ajuda? ")
    leia (n)
    para(inteiro i = 1; i <= n; i++)
    escreva ("Bat-sinal ativado!\n")

    
  }
}
