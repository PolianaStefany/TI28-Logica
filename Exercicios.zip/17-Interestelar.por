/*17.	Cálculo de Anos no Espaço (Interestelar)
A cada 1 hora passada no planeta de água, passam-se 7 anos na Terra. Crie um laço que receba quantas horas a tripulação ficou lá e calcule o total de anos passados na Terra.
*/


programa {
  funcao inicio() {
    inteiro horas_no_planeta, hora_atual
        inteiro anos_na_terra = 0

        escreva("Quantas horas a tripulação passará no planeta de água? ")
        leia(horas_no_planeta)

        escreva("\n--- Linha do Tempo de Miller ---\n")
        
        // O laço simula a passagem do tempo hora por hora
        para (hora_atual = 1; hora_atual <= horas_no_planeta; hora_atual++)
        {
            anos_na_terra = anos_na_terra + 7
            escreva("Hora ", hora_atual, " no planeta = ", anos_na_terra, " anos passados na Terra.\n")
        }

        escreva("\nTotal de tempo decorrido na Terra: ", anos_na_terra, " anos.\n")
    }
}
  }
}
