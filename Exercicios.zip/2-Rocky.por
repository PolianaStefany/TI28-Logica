/*2.	Treinamento do Rocky Balboa (Rocky)
Use um laço para contar 50 flexões, exibindo "Flexão número X concluída!" a cada repetição.*/



programa {
  funcao inicio() {
    
    inteiro contador 
     para (contador = 1; contador <= 50; contador++) {
      escreva("Flexão número ", contador, " concluída!\n")
    }
  

    
  }
}
