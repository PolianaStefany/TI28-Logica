/*19.	O Loop Temporal de Bill Murray (Feitiço do Tempo)
Crie uma variável acordou_bem = False. O laço deve repetir a mensagem "O rádio toca: I Got You Babe..." e perguntar ao usuário [s/n] se o dia foi bom, repetindo até a resposta ser "s".
*/

programa {
  funcao inicio() {
    logico acordou_bem = falso
        cadeia resposta

        enquanto (nao acordou_bem)
        {
            escreva("O rádio toca: I Got You Babe...\n")
            escreva("O seu dia foi bom? [s/n]: ")
            leia(resposta)

             se (resposta == "s" ou resposta == "S")
            {
                acordou_bem = verdadeiro
                escreva("\nO loop foi quebrado! Amanhã finalmente será um novo dia!\n")
            }
            senao
            {
                escreva("Nada mudou. Você vai dormir...\n\n")
            }
        }
    }
    
  }
}
