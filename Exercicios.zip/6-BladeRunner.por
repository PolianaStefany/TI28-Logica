/*6.	Identificador de Replicantes (Blade Runner)
Percorra uma contagem de 1 a 10 suspeitos. Se o número for par, imprima "Humano", se for ímpar, "Replicante".*/


programa {
  funcao inicio() {

		para (inteiro i = 1; i <= 10; i++)
		{
			// Verifica se o número do suspeito é par
			se (i % 2 == 0)
			{
				escreva("Suspeito ", i, ": Humano\n")
			}
			senao
			{
				escreva("Suspeito ", i, ": Replicante\n")
			}
		}
	}

    
  }
}
