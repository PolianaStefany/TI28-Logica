/*18.	Encontrando a Pérola Negra (Piratas do Caribe)
Gere um laço de 1 a 20 representando milhas navegadas. Pare a execução imediatamente (break) assim que a milha 13 for alcançada, imprimindo "Navio avistado!".
*/


programa {
  funcao inicio() {
    inteiro milha

        para (milha = 1; milha <= 20; milha++)
        {
            escreva("Navegando... Milha ", milha, "\n")
            
           
            se (milha == 13)
            {
                escreva("\n[!] Navio avistado na milha ", milha, "! Lançar âncoras!\n")
                pare 
            }
        }
        
        escreva("Fim da busca pela Pérola Negra.\n")
    }
}
  }
}
