/*8.	A Divisão dos Minions (Meu Malvado Favorito)
Percorra números de 1 a 30. Imprima "Minion Amarelo" para múltiplos de 3 e "Minion Roxo" para múltiplos de 5.*/



programa {
  funcao inicio() {
   