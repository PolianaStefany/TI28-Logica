/* Contagem Regressiva para a Estrela da Morte (Star Wars)
Crie um laço que faça uma contagem regressiva de 10 até 1 e imprima "Fogo!" no final */

programa
{
    funcao inicio()
    {
        inteiro contador

        escreva("Contagem regressiva: \n")

        para (contador = 10; contador >= 1; contador--)
        {
            escreva(contador, "\n ")
        }

        escreva("\nFogo!")
    }
}
}
