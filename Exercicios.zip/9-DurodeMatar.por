/* 9.	Os 100 Andares do Prédio (Duro de Matar)
Simule a subida de John McClane por 10 andares. Apenas no 5º andar imprima "Encontrou terroristas!", nos demais imprima "Andar seguro".*/

programa {
  funcao inicio() {
    
        para (inteiro andar = 1; andar <= 10; andar++) {
            se (andar == 5) {
                escreva("5º Andar: Encontrou terroristas!\n")
            } senao {
                escreva(andar, "º Andar: Andar seguro\n")
            }
        }
    }
  }
}
