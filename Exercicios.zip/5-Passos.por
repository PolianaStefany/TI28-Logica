/*5.	Passos no Labirinto (O Iluminado)
Faça um laço que conte de 2 em 2, de 0 a 20, representando os passos dados na neve*/


programa {
  funcao inicio() {
    
    escreva ("Passos dado na neve \n")
    para (inteiro i = 0; i <= 20; i+=2){

      escreva ("passos ", i, " ")
    }
    
    
  }
}
