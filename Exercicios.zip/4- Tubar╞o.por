/*4.	Trilha Sonora Repetitiva (Tubarão)
Imprima a expressão "Tubarão à vista!" 5 vezes na tela usando um laço for ou while. */


programa {
  funcao inicio() {
    inteiro contador 
     para (contador = 1; contador <= 5; contador++) {
      escreva("Tubarão à vista!\n")
    }
    
  }
}
