/*11.	Somando as Moedas de Ouro do Smaug (O Hobbit)
Peça ao usuário para inserir o valor de 5 baús de tesouro e, usando um laço, calcule e exiba a soma total de ouro.*/


programa {
  funcao inicio() {
    real valorBau, somaTotal
		inteiro contador

		somaTotal = 0.0

		escreva("=== Contador de Ouro do Smaug ===\n\n")

		// Laço para ler o valor dos 5 baús
		para (contador = 1; contador <= 5; contador++)
		{
			escreva("Digite o valor em ouro do ", contador, "º baú: ")
			leia(valorBau)

			// Somando o valor digitado ao total existente
			somaTotal = somaTotal + valorBau
		}

		// Exibição do resultado final
		escreva("\nA soma total das moedas de ouro do Smaug é: ", somaTotal, " moedas.\n")
	}
}
  }
}
