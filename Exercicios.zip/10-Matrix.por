/*10.	A Escolha da Pílula (Matrix)
Crie um laço que continue pedindo uma cor ("azul" ou "vermelha") até que o usuário digite "vermelha".
Nível Avançado (Acumuladores e Validações)*/

programa {
  funcao inicio() {
    cadeia vermelha
    cadeia azul
