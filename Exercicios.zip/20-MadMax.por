/*20.	Fórmula do Combustível (Mad Max: Estrada da Fúria)
Receba a quantidade de litros colocados no caminhão a cada parada até que o usuário digite -1 (flag de parada). Ao final, mostre o total de combustível acumulado.

*/


programa {
  funcao inicio() {
    real litros = 0.0
        real total_combustivel = 0.0

       
        escreva("--- Abastecimento do Caminhão de Guerra ---\n")
        escreva("Digite a quantidade de litros ou -1 para encerrar.\n\n")

        enquanto (litros != -1.0)
        {
            escreva("Litros colocados na parada: ")
            leia(litros)

    
            se (litros != -1.0)
            {
                total_combustivel = total_combustivel + litros
            }
        }

        escreva("\n--- Carregamento Concluído ---\n")
        escreva("Total de combustível acumulado: ", total_combustivel, " litros.\n")
    }
}
  }
}
